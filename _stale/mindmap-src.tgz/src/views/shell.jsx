import React from 'react'
import { Back } from './Monitor'
import KineticGrid from '../s21/texture'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../ui/tabs'
import { Badge } from '../ui/badge'

/* One section shell for the three audiences.
 *
 * "For schools" had this layout and the other two did not — a student or a
 * parent arriving from the nav landed straight on a bare dashboard with no
 * heading saying who the page was for. All three are sections now, built from
 * the same piece, so the difference between them is their content and nothing
 * else. */
export function SectionShell({ title, sub, note, tabs, panes, go, tab, onTab, children }) {
  const [said, setSaid] = React.useState('')
  /* Switching a tab replaces the panel with focus still on <body>. */
  const announce = v => {
    const label = tabs?.find(t => t[0] === v)?.[1]
    setSaid('')
    requestAnimationFrame(() => setSaid(label ? `${label} — showing now` : ''))
  }
  const pick = v => { onTab(v); announce(v) }
  return (
    <main>
      <div className="relative overflow-hidden border-b border-rule bg-mist">
        <KineticGrid aria-hidden className="absolute inset-0" globalColor="monochrome"/>
        <div className="wrap relative py-6 sm:py-8">
          <Back go={go} to="site" label="Overview"/>
          <h1 className="font-display font-medium text-major leading-[1.05] tracking-tight text-ink">{title}</h1>
          {sub && <p className="mt-3 max-w-[60ch] text-sec text-ink-2">{sub}</p>}
          {note && (
            <p className="mt-4 inline-flex max-w-[60ch] items-baseline gap-2 border-l-2 border-warn
              bg-paper/70 py-2 pl-3 pr-4 text-meta text-ink-2">
              {/* The sample-data disclosure used to be a hand-set <b> in warn;
                  it is the one thing the sourced badge's `demo` variant exists
                  for, and it now reads the same here and on the pro console. */}
              <Badge variant="demo">Demo</Badge>
              {note}</p>
          )}
        </div>
      </div>
      <div className="wrap py-9 sm:py-12">
        <p aria-live="polite" className="sr-only text-sec">{said}</p>
        {tabs ? (
          /* Was a hand-classed @radix-ui/react-tabs tree repeating the trigger
             string this shell shared with the pro console; both now come from
             ui/tabs, so the selected-tab rule is defined in one place. */
          <Tabs value={tab} onValueChange={pick}>
            <TabsList aria-label={`${title} views`}>
              {tabs.map(([v, label]) => (
                <TabsTrigger key={v} value={v}>{label}</TabsTrigger>
              ))}
            </TabsList>
            {tabs.map(([v]) => {
              const Pane = panes[v]
              return (
                <TabsContent key={v} value={v}>
                  <Pane go={go} openTab={pick}/>
                </TabsContent>
              )
            })}
          </Tabs>
        ) : children}
      </div>
    </main>
  )
}
